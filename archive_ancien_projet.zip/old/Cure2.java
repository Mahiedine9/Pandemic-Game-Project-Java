package old;

import pandemicgame.Disease;

public class Cure2 {
    private Disease disease;

    public Cure2(Disease disease) {
        this.disease = disease;
    }

    public Disease getDisease() {
        return disease;
    }
}
