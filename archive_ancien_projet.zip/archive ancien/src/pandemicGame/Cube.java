package pandemicGame;

public class Cube {

	private Disease disease ;

	public Cube(Disease disease) {
		this.disease = disease ;
	} 

	public Disease getDisease(){
		return this.disease;
	} 
}
