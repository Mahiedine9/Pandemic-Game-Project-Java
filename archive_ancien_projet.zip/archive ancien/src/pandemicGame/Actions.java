public interface Actions{
    private 
    public void action();

}
