package pandemicGame;

public class Doctor extends Role {

    public Doctor(){
        super();
    }

    public void treatingDisease(City city){
        city.removeAllCubes();
    }










}
