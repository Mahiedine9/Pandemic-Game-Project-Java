package pandemicGame;

public class Role {
    private City city;
    private Player player;

    public Role (City city, Player player){
        this.city = city;
        this.player = player;
    }








}
