public class Move implements Actions{
    

    public Move(){

    }

    public void moveToNeighbourCity(City city){


    }






}