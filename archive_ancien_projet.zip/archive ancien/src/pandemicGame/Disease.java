package pandemicGame;

public class Disease {
	private boolean diseaseCured;

	public Disease() {
		this.diseaseCured = false;
	}
	public void CureDisease(){
		this.diseaseCured = true;
	} 

}
