package pandemicGame;

public class FindDisease implements Actions{

    public FindDisease(){
                   
    }




}