package pandemicGame;

public class BuildStation implements Actions{


    public BuildStation(){

    }

    public void Build(){
        
    }





}