package pandemicGame;

public class Expert extends Role{

    public Expert(){
        super();
    }

    public void BuildStation(City city){
        city.buildResearchStation();
    }


}
